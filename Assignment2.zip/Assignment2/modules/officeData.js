/*********************************************************************************
* WEB700 – Assignment 2
* I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part of 
* this assignment has been copied manually or electronically from any other source (including web sites) 
* or distributed to other students.
*
* Name: Hem Vishnu Joshi Student ID: 144010212 Date: Feburary 02th 2022
*
********************************************************************************/
const fs = require("fs");

class data {
    constructor(employees, classes){
        this.employees = employees;
        this.classes = classes;
    }
}

let dataCollection = null

// Read contents of the employees and classes json files and make data useable
module.exports.initialize = function(){
    return new Promise((resolve, reject)=>{
        fs.readFile('./data/classes.json','utf-8',(err, classesData) =>{
            if(err){
                reject("Unable to load classes"); return;
            }

            fs.readFile('./data/employees.json','utf-8',(err, employeesData) =>{
                if(err){
                    reject("Unable to load employees"); return;
                }
            dataCollection = new data(JSON.parse(employeesData), JSON.parse(classesData));
            resolve();
            });
       });
    });
}


// Function provides an array of objects which are stored in the employees.json file
module.exports.getAllEmployees = function(){
    return new Promise ((resolve, reject) =>{
        if (dataCollection.employees.length == 0){
            reject ("query returned 0 results"); return;
        }
        resolve(dataCollection.employees);
    })
}

// Function provides an array of objects which are stored in the classes.json file
module.exports.getClasses = function(){
    return new Promise ((resolve, reject) =>{
        if (dataCollection.classes.length == 0){
            reject ("query returned 0 results"); return;
        }
        resolve(dataCollection.classes);
    })
}

// Funtion returns an array of objects (employees) for which the EA is true
module.exports.getEAs = function(){
    return new Promise ((resolve, reject) =>{
        var eaEmployees = [];
        for (let i = 0; i < dataCollection.employees.length; i++){
            if(dataCollection.employees[i].EA == true){
                eaEmployees.push(dataCollection.employees[i]);
            }
        }
        if (dataCollection.classes.length == 0){
            reject ("query returned 0 results"); return;
        }
        resolve(eaEmployees);
    })
}

// Function returns an array of employees for which status is part time
module.exports.getPartTimers = function(){
    return new Promise ((resolve, reject) =>{
        var partTimeEmployees = [];
        for (let i = 0; i < dataCollection.employees.length; i++){
            if(dataCollection.employees[i].status == "Part Time"){
                partTimeEmployees.push(dataCollection.employees[i]);
            }
        }
        if (dataCollection.classes.length == 0){
            reject ("query returned 0 results"); return;
        }
        resolve(partTimeEmployees);
    })
}