/*********************************************************************************
* WEB700 – Assignment 2
* I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part of 
* this assignment has been copied manually or electronically from any other source (including web sites) 
* or distributed to other students.
*
* Name: Hem Vishnu Joshi Student ID: 144010212 Date: Feburary 02th 2022
*
********************************************************************************/

// get data from the following path
var data = require("./modules/officeData.js")

// call funtion getAllEmployees() within officedata. Returns number of objects within employees.json
data.initialize().then(function(){
    data.getAllEmployees().then(function(data){
        console.log("Successfully retrieved " + data.length + " Employees")
        }).catch(function(err){
            console.log(err)
        });

    }).catch((err)=>{
        console.log(err)

})

// call function getClasses() within officeData. Returns number of objects within the Classes.json
data.initialize().then(function(){
    data.getClasses().then(function(data){
        console.log("Successfully retrieved " + data.length + " claases")
        }).catch(function(err){
            console.log(err)
        });

    }).catch((err)=>{
        console.log(err)

})

// calls function getEas within officeData. Returns number of employees where EA is true
data.initialize().then(function(){
    data.getEAs().then(function(data){
        console.log("Successfully retrieved " + data.length + " EAs")
        }).catch(function(err){
            console.log(err)
        });

    }).catch((err)=>{
        console.log(err)

})

// calls function getPartTimers() within officeData. Returns number of employees where status is Part time
data.initialize().then(function(){
    data.getPartTimers().then(function(data){
        console.log("Successfully retrieved " + data.length + " Part-Timers")
        }).catch(function(err){
            console.log(err)
        });

    }).catch((err)=>{
        console.log(err)

})
