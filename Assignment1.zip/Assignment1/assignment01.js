/*********************************************************************************
* WEB700 – Assignment 01
* I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part of 
* this assignment has been copied manually or electronically from any other source (including web sites) 
* or distributed to other students.
*
* Name:  Student ID:  Date: January 20th 2022
*
********************************************************************************/

/*****************************
* Task 1
*****************************/

// Downloaded and installed Visual studio code, Git and Node.js

/*****************************
* Task 2
*****************************/

function logSomeThings() {
    var total = 0
    for (var i = 0; i < arguments.length; ++i) {
        total += arguments[i];
    }
    var avg = total / arguments.length;

    if (avg >= 25){
        console.log("Average grater than or equal to 25: True")
        return true
    }
    else{
        console.log("Average is less than to 25: False")    
        return false
    }
}

// logSomeThings(1,2,3)
// logSomeThings(23,43,25)
// logSomeThings(7,6,23)

/*****************************
* Task 3
*****************************/


function showMultiples(num, numMultiples){
    var result = ""
    for (var i = 1; i <= numMultiples; i++){
         result += (num +" x " +i+" = ")+(num * i)+"\n"
    }
    return result
}
// console.log(showMultiples(5, 4))
// console.log(showMultiples(6, 3))
// console.log(showMultiples(2, 5))

/*****************************
* Task 4
*****************************/

var Increment = (function (){
    counter = 100
    return function() {
        counter += 100;
        return counter;
    };

})
();

var incr = Increment();
    incr = Increment();
    incr = Increment();

// console.log(incr)

/*****************************
* Task 5
*****************************/

function testing(){
    console.log("Testing function Call");
}

// setInterval(testing,1000);

/*****************************
* End of code
*****************************/

var varC = 5;

 

function showVars(varA) {

varC += varA;

return function (varB) {

varA++;

return "varA: " + varA + "\nvarB: " + varB + "\nvarC: " + varC;

};

}

 

myVars = showVars(5);

console.log(myVars(8));