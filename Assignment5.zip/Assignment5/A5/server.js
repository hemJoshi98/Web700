/*********************************************************************************
* WEB700 – Assignment 05
* I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part 
* of this assignment has been copied manually or electronically from any other source 
* (including 3rd party web sites) or distributed to other students.
* 
* Name: Hem Vishnu Joshi Student ID: 144010212 Date: March 25nd 2022*
* Online (Heroku) Link: https://secure-ridge-01803.herokuapp.com/
*
********************************************************************************/
const express = require("express");
const path = require("path");
const exphbs = require("express-handlebars");
const data = require("./modules/officeData.js");


const app = express();

const HTTP_PORT = process.env.PORT || 8080;

app.engine('.hbs', exphbs.engine({ 
    extname: '.hbs',
    defaultLayout: "main",
}));

app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));

app.set("view engine", ".hbs");

app.get("/PartTimer", (req,res) => {
    data.getPartTimers().then(()=>{
        res.redirect("/employees");
    });
});

app.get("/", (req, res) => {
    res.redirect("/employees");
   });
   

app.get("/employees/add", (req,res) => {
    res.sendFile(path.join(__dirname, "/views/addEmployee.html")); 
});

app.post("/employees/add", (req, res) => {
    data.addEmployee(req.body).then(()=>{
    res.redirect("/employees"); 
}); 
});

app.get("/employees", (req, res) => {
    data.getAllEmployees().then((data)=>{
        if (data.length > 0) {
            res.render("employees", { employees: data });
        } else {
            res.render("employees", { message: "no results" });
        }
    }).catch((err) => {
        res.render(err.message);
    });
});

app.get("/description", (req, res) => {
    res.render("description");
   });

app.use((req,res)=>{
    res.status(404).send("Page Not Found");
});


data.initialize().then(function(){
    app.listen(HTTP_PORT, function(){
        console.log("app listening on: " + HTTP_PORT)
    });
}).catch(function(err){
    console.log("unable to start server: " + err);
});

